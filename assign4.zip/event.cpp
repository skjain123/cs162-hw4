#include "event.h"

#include <iostream>

using namespace std;

string Event::get_name() const {
    return "";
}

void Event::set_name(string s) {
    //sdf
}

char Event::get_symbol() const {
    //sdf
    return ' ';
}

void Event::print_event_precept() {
    //sdf
}

void Event::exec(bool* kill_player, bool* has_gold, int* reverse_controls) {
    //sdf
}

Event::Event() {
    //sdf
}

Event::Event(string s) {
    //sdf
}

Event::~Event() {
    //sdf
}

Event::Event(const Event& e) {
    //sdf
}

Event& Event::operator=(Event const& e) {
    
	return *this;
}

